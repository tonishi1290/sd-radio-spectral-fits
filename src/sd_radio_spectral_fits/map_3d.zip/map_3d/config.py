# src/sd_radio_spectral_fits/map/config.py
from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import Optional, Literal, Union


@dataclass
class MapConfig:
    """
    画像化(Gridding)およびマップ解析の統合設定クラス。
    旧 GridConfig の全機能を包含し、解析用パラメータを追加。

    Notes
    -----
    既定の kernel_preset='mangum2007' は、single-dish OTF gridding の
    文献・実務で広く使われる Bessel×Gauss / Gaussian の既定値に合わせて、
    beam FWHM から kernel 幅を自動生成する。
    kernel_sign='auto' のときは、mangum2007 では signed、legacy では
    positive_only を既定として解決する。
    明示的な *_pix / *_beam / support_radius_* が与えられた場合は、
    それらを最優先する。
    """

    # --- 1. 空間グリッド定義 (Geometry) ---
    x0: float                # マップ中心からのオフセット [arcsec]
    y0: float
    nx: int                  # ピクセル数
    ny: int
    cell_arcsec: float       # ピクセルサイズ [arcsec]
    beam_fwhm_arcsec: float  # 望遠鏡のビームサイズ [arcsec]

    # --- 2. グリッディング・カーネル設定 ---
    kernel: Literal['gjinc', 'gauss'] = 'gjinc'
    kernel_preset: Literal['mangum2007', 'legacy'] = 'mangum2007'
    kernel_sign: Literal['auto', 'signed', 'positive_only'] = 'auto'

    # kernel_sign は GJINC/GAUSS の負重みをどう扱うかを表す。
    #   auto          : mangum2007 -> signed, legacy -> positive_only
    #   signed        : 有限な符号付き重みをそのまま使う
    #   positive_only : 正の重みだけを使う
    # 明示指定がある場合は *_pix > *_beam > preset default の順で解決する
    gwidth_pix: Optional[float] = None
    gwidth_beam: Optional[float] = None
    jwidth_pix: Optional[float] = None
    jwidth_beam: Optional[float] = None

    # support は kernel をどの半径で打ち切るかを表す cutoff radius。
    # pix / beam / truncate の順で解決する。
    # truncate=None のときは preset default を用いる。
    #   mangum2007 + gjinc : support = beam FWHM
    #   mangum2007 + gauss : support = 3a = 3 * gwidth / sqrt(log(2))
    #   legacy     + gjinc : support = first null of resolved jinc width
    #   legacy     + gauss : support = 3 * gwidth (3 * HWHM)
    truncate: Optional[Union[Literal['first_null'], float]] = None
    support_radius_pix: Optional[float] = None
    support_radius_beam: Optional[float] = None

    chunk_ch: int = 256      # メモリ節約のためのチャンネル分割処理（デフォルト256）
    dtype: str = "float32"

    # --- 3. 重み付け・品質管理 ---
    # 論文向けの既定: RMS が信頼できる場合の逆分散重みを既定にする。
    # q *= (1 / rms^2)^alpha_rms なので、alpha_rms=1.0 -> q \propto 1/rms^2。
    # beta_tint は RMS に積分時間の効果がすでに入っている前提で既定 0.0 とする。
    # weight_clip_quantile は既定では無効化し、必要時のみ明示指定で使う。
    alpha_rms: float = 1.0
    beta_tint: float = 0.0
    weight_clip_quantile: Optional[float] = None
    weight_clip_max: Optional[float] = None
    exclude_turnaround: bool = True

    # --- 4. 推定器 / QC / 安全係数 ---
    estimator: Literal['avg', 'plane'] = 'avg'
    n_min_avg: int = 2
    n_min_plane: int = 6
    cond_max: float = 1e6
    dr_eff_warn_pix: float = 0.2
    eps_u0: float = 0.01
    eps_weight_sum: float = 1e-8

    # 追加の post-gridding 妥当性判定
    # min_abs_weight_ratio > 0 のとき、|WEIGHT| / median(|WEIGHT|) が
    # この値未満の画素を無効化する。CASA minweight と同趣旨。
    min_abs_weight_ratio: float = 0.0
    # min_cancel_ratio > 0 のとき、|WSUM| / WABS がこの値未満の
    # 画素を無効化する。signed kernel の強い相殺を検出する。
    min_cancel_ratio: float = 0.0

    # beam / sampling に関する補助
    warn_if_cell_coarse: bool = True       # cell > beam/3 のとき warning
    estimate_effective_beam: bool = True   # nominal / empirical beam を推定

    # --- 5. 出力マップ制御 (core.py が要求するフラグ群) ---
    fill_nan_for_invalid: bool = True
    emit_diag_maps: bool = True
    emit_neff_map: bool = True
    emit_rms_map: bool = True
    emit_time_map: bool = True
    emit_tint_map: bool = True
    emit_tsys_map: bool = True

    # =========================================================
    # --- 6. 解析・出力設定 (Step 3以降で使用) ---
    # =========================================================
    generate_mask: bool = False      # 3DマスクとMoment0を自動生成するか
    mask_method: str = "smooth_mask" # 'simple', 'smooth_mask', 'derivative'

    # 共通 / simple用
    mask_sigma: float = 3.0          # マスク生成のベース閾値

    # smooth_mask用
    mask_high_snr: float = 3.0       # コア抽出の閾値
    mask_low_snr: float = 1.5        # 拡張マスクの閾値
    mask_min_vol: int = 27           # 許容する最小体積(ピクセル数)

    # derivative用
    mask_sigma_v: float = 2.0        # 速度方向のフィルタ幅(チャンネル数)
    mask_deriv_snr: float = 3.0      # 2次微分の検出閾値
    mask_dilation: int = 2           # 速度方向へのマスク拡張幅

    # 運用・出力用
    mask_compression: Optional[str] = 'PLIO_1' # FITS保存時の圧縮形式 (互換性重視ならNoneも可)
    dv_kms: Optional[float] = None   # 速度リグリッドの分解能 [km/s]
    output_prefix: str = "map"      # 出力ファイルの接頭辞

    # --- 7. 実行バックエンド ---
    backend: str = 'numpy'           # 'numpy' or 'numba' (将来用)

    # --- 8. 実行時オプション ---
    verbose: bool = False
    workers: int = -1                # cKDTree query_ball_point 用。旧挙動は -1。
    sort_neighbors: bool = False     # 旧挙動維持のため既定は False。
    reproducible_mode: bool = False  # True のとき float64 / workers=1 / sort固定。
    write_diagnostics: bool = False  # True のとき OTF 診断 sidecar を出力。
    diagnostics_prefix: Optional[str] = None  # 診断ファイルの接頭辞。


# 以前のコードとの互換性のためにエイリアスを残す
GridConfig = MapConfig


@dataclass
class GridInput:
    """入力データ構造"""
    x: np.ndarray
    y: np.ndarray
    spec: np.ndarray
    flag: np.ndarray
    time: np.ndarray
    rms: Optional[np.ndarray] = None
    tint: Optional[np.ndarray] = None
    tsys: Optional[np.ndarray] = None
    scan_id: Optional[np.ndarray] = None
    subscan_id: Optional[np.ndarray] = None
    scan_dir: Optional[np.ndarray] = None
    is_turnaround: Optional[np.ndarray] = None


@dataclass
class GridResult:
    """出力データ構造"""
    cube: np.ndarray
    weight_map: np.ndarray
    hit_map: np.ndarray   # 実際に gridding 分母に使ったサンプル数（sign filter 後）
    mask_map: np.ndarray  # 空間的な分母有効性（channel ごとの NaN マスク前）
    nsamp_map: Optional[np.ndarray] = None  # support 内の有限サンプル数（sign filter 前）
    wsum_map: Optional[np.ndarray] = None
    wabs_map: Optional[np.ndarray] = None
    cancel_map: Optional[np.ndarray] = None  # |WSUM| / WABS
    weight_rel_map: Optional[np.ndarray] = None  # |WEIGHT| / median(|WEIGHT|)
    # 診断用マップ群
    xeff_map: Optional[np.ndarray] = None
    yeff_map: Optional[np.ndarray] = None
    dr_eff_map_pix: Optional[np.ndarray] = None
    neff_map: Optional[np.ndarray] = None
    rms_map: Optional[np.ndarray] = None
    time_map: Optional[np.ndarray] = None
    tint_map: Optional[np.ndarray] = None
    tsys_map: Optional[np.ndarray] = None
    meta: Optional[dict] = None

    # ==========================================
    # --- Step 3 解析結果格納用 ---
    # ==========================================
    mask_3d: Optional[np.ndarray] = None
    mom0_map: Optional[np.ndarray] = None
